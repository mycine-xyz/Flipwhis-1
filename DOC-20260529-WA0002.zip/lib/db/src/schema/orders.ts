import { pgTable, text, serial, json, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export interface OrderItemData {
  productId: number;
  name: string;
  brand: string;
  price: number;
  imageUrl: string;
  size: string;
  color: string;
  quantity: number;
}

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  items: json("items").$type<OrderItemData[]>().notNull().default([]),
  total: real("total").notNull(),
  status: text("status").notNull().default("Processing"),
  address: text("address").notNull(),
  paymentMethod: text("payment_method").notNull().default("COD"),
  expectedDelivery: text("expected_delivery"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({ id: true, createdAt: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
